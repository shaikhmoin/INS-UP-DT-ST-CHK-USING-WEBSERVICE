//
//  ViewController.swift
//  Demo
//
//  Created by MACOS on 7/5/17.
//  Copyright © 2017 king. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var finalarr = [Any]()
    
    @IBOutlet var tbl: UITableView!
    @IBOutlet var txtpwd: UITextField!
    @IBOutlet var txtemail: UITextField!
    @IBOutlet var txtid: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("http://localhost/iphone/select.php")
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            //let str1 = String(data: data1!, encoding: String.Encoding.utf8)
            // print(str1)
            
            DispatchQueue.main.sync {
                do
                {
                    let json = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any]
                    
                    for item in json
                    {
                        //var temp = [String]()
                        //temp.append(item["Name"] as! String)
                        //temp.append(item["Address"] as! String)
                        
                        self.finalarr.append(item)
                        self.tbl.reloadData()
                    }
                    print(self.finalarr)
                }
                catch
                {
                    
                }
            }
            
        })
        
        datatask.resume()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnInsert(_ sender: Any) {
        
        let str = String("http://localhost/iphone/insert.php")
        
        let param = String("email=\(txtemail.text!)&password=\(txtpwd.text!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            let str1 = String(data: data1!, encoding: String.Encoding.utf8)
            print(str1)
            
        })
        
        datatask.resume()
        
    }
    @IBAction func btndelete(_ sender: Any) {
        let str = String("http://localhost/iphone/delete.php")
        
        let param = String("Id=\(txtid.text!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            let str1 = String(data: data1!, encoding: String.Encoding.utf8)
            print(str1)
            
        })
        
        datatask.resume()

        
    }

    @IBAction func btnupdate(_ sender: Any) {
        
        let str = String("http://localhost/iphone/update.php")
        
        let param = String("Id=\(txtid.text!)&email=\(txtemail.text!)&password=\(txtpwd.text!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            let str1 = String(data: data1!, encoding: String.Encoding.utf8)
            print(str1)
            
        })
        
        datatask.resume()
    }

    @IBAction func btnlogin(_ sender: Any) {
        
        let str = String("http://localhost/iphone/checklogin.php")
        
        let param = String("email=\(txtemail.text!)&password=\(txtpwd.text!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
        
            DispatchQueue.main.sync {
                do
                {
                    let json = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any]
             
                    if json.count == 1
                    {
                        let nav = self.storyboard?.instantiateViewController(withIdentifier: "next")
                        self.navigationController?.pushViewController(nav!, animated: true)
   
                    }
                    
                    else
                    {
                        print("Something wrong")
                    }
                }
                catch
                {
                    
                }
            }
            
            /*   if err != nil
            {
                print("success")
                return
            }
            
            print("response = \(err)")
            
           
            let resstring = NSString(data: data1!, encoding: String.Encoding.utf8.rawValue)
            
            print("responsestring = \(resstring)") */
         
           // let str1 = String(data: data1!, encoding: String.Encoding.utf8)
           // print(str1)
            
        })
        
        datatask.resume()
        
       
        
    }
   
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let dicfinal = finalarr[indexPath.row] as! [String:Any]
        
        cell.textLabel?.text = dicfinal["email"] as! String
        
        cell.detailTextLabel?.text = dicfinal["password"] as! String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let st = finalarr[indexPath.row] as! [String:Any]
        
        txtid.text = st["Id"] as! String
        txtemail.text = st["email"] as! String
        txtpwd.text = st["password"] as! String
    }
    
}

