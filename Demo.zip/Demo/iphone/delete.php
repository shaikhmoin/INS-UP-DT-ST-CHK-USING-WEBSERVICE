<?php
    $con=new mysqli("localhost","root","","demo");
    
    
    $a = $_POST['Id'];
   // print($a);
    
   echo $qp="delete from tblemp where Id='$a'";
    
    $con -> query($qp);
    echo "success";
   
?>
