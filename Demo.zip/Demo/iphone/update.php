<?php

    $con=new MySQLi("localhost","root","","demo");
    
    $id = $_POST["Id"];
    $email = $_POST["email"];
    $pwd = $_POST["password"];

    
    echo $qu="update tblemp set email='$email', password='$pwd' where Id='$id'";

    $con->query($qu);
    
    echo "success";
    
?>

