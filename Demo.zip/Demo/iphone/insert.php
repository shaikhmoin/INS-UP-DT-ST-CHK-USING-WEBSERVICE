<?php
    $con=new mysqli("localhost","root","","demo");

    $email = $_POST["email"];
    $pwd = $_POST["password"];
    
    $query = "insert into tblemp(email,password)values('$email','$pwd')";
    
    $con -> query($query);
    echo "success";   
?>
